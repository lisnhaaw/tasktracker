import streamlit as st
from utils.visualizations import create_completion_heatmap, create_completion_rate_chart

def render_stats_view():
    """Render the statistics and visualizations view."""
    st.subheader("Habit Statistics")
    
    habits = st.session_state.data_manager.get_habits()
    tracking_data = st.session_state.data_manager.get_tracking_data()
    
    if not habits or not tracking_data:
        st.info("Start tracking your habits to see statistics!")
        return
    
    # Overall statistics
    col1, col2, col3 = st.columns(3)
    
    with col1:
        total_habits = len(habits)
        st.metric("Total Habits", total_habits)
    
    with col2:
        total_tracked = len(tracking_data)
        st.metric("Total Check-ins", total_tracked)
    
    with col3:
        if tracking_data:
            completion_rate = sum(1 for t in tracking_data if t['completed']) / len(tracking_data) * 100
            st.metric("Overall Completion Rate", f"{completion_rate:.1f}%")
    
    # Visualizations
    st.markdown("### Completion Heatmap")
    heatmap = create_completion_heatmap(tracking_data, habits)
    if heatmap:
        st.plotly_chart(heatmap, use_container_width=True)
    
    st.markdown("### Completion Rates by Habit")
    completion_chart = create_completion_rate_chart(tracking_data, habits)
    if completion_chart:
        st.plotly_chart(completion_chart, use_container_width=True)
