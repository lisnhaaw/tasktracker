import streamlit as st
from datetime import datetime

def render_habit_list():
    """Render the list of habits and tracking interface."""
    st.subheader("Track Your Habits")
    
    habits = st.session_state.data_manager.get_habits()
    if not habits:
        st.info("No habits created yet. Create your first habit using the form!")
        return
    
    # Date selector
    selected_date = st.date_input(
        "Select Date",
        value=datetime.now(),
        max_value=datetime.now()
    )
    
    st.markdown("### Today's Habits")
    
    # Create columns for the habit list header
    col1, col2, col3, col4 = st.columns([3, 2, 2, 1])
    with col1:
        st.markdown("**Habit**")
    with col2:
        st.markdown("**Frequency**")
    with col3:
        st.markdown("**Streak**")
    with col4:
        st.markdown("**Done**")
    
    # Display each habit
    for habit in habits:
        col1, col2, col3, col4 = st.columns([3, 2, 2, 1])
        
        with col1:
            st.write(habit['name'])
        
        with col2:
            st.write(habit['frequency'])
        
        with col3:
            streak = st.session_state.data_manager.get_streak(habit['id'])
            st.write(f"🔥 {streak}")
        
        with col4:
            # Get current tracking status
            tracking_data = st.session_state.data_manager.get_tracking_data(habit['id'])
            current_status = next(
                (entry['completed'] for entry in tracking_data 
                 if entry['date'] == selected_date.strftime('%Y-%m-%d')),
                False
            )
            
            # Checkbox for tracking
            if st.checkbox(
                "Complete",
                value=current_status,
                key=f"habit_{habit['id']}_{selected_date}"
            ):
                st.session_state.data_manager.track_habit(
                    habit['id'],
                    selected_date.strftime('%Y-%m-%d'),
                    True
                )
            else:
                st.session_state.data_manager.track_habit(
                    habit['id'],
                    selected_date.strftime('%Y-%m-%d'),
                    False
                )
