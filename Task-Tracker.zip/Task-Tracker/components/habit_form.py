import streamlit as st
from datetime import datetime

def render_habit_form():
    """Render the habit creation form."""
    st.subheader("Create New Habit")
    
    with st.form("habit_form", clear_on_submit=True):
        name = st.text_input("Habit Name")
        description = st.text_area("Description")
        frequency = st.selectbox(
            "Frequency",
            ["Daily", "Weekly", "Monthly"]
        )
        
        submitted = st.form_submit_button("Create Habit")
        
        if submitted and name:
            st.session_state.data_manager.add_habit(name, description, frequency)
            st.success(f"Habit '{name}' created successfully!")
        elif submitted:
            st.error("Please enter a habit name.")
