import pandas as pd
import json
from datetime import datetime, timedelta
import streamlit as st

class HabitDataManager:
    def __init__(self):
        # Initialize or load habits and tracking data
        if 'habits' not in st.session_state:
            st.session_state.habits = []
        if 'tracking_data' not in st.session_state:
            st.session_state.tracking_data = []

    def add_habit(self, name, description, frequency):
        """Add a new habit to the list."""
        habit = {
            'id': len(st.session_state.habits),
            'name': name,
            'description': description,
            'frequency': frequency,
            'created_at': datetime.now().strftime('%Y-%m-%d')
        }
        st.session_state.habits.append(habit)
        return habit

    def get_habits(self):
        """Return all habits."""
        return st.session_state.habits

    def track_habit(self, habit_id, date, completed):
        """Track a habit for a specific date."""
        tracking_entry = {
            'habit_id': habit_id,
            'date': date,
            'completed': completed
        }
        
        # Remove existing entry for the same habit and date if it exists
        st.session_state.tracking_data = [
            entry for entry in st.session_state.tracking_data 
            if not (entry['habit_id'] == habit_id and entry['date'] == date)
        ]
        
        st.session_state.tracking_data.append(tracking_entry)

    def get_tracking_data(self, habit_id=None):
        """Get tracking data, optionally filtered by habit_id."""
        if habit_id is None:
            return st.session_state.tracking_data
        return [
            entry for entry in st.session_state.tracking_data 
            if entry['habit_id'] == habit_id
        ]

    def get_streak(self, habit_id):
        """Calculate current streak for a habit."""
        entries = sorted(
            [entry for entry in self.get_tracking_data(habit_id) if entry['completed']],
            key=lambda x: x['date'],
            reverse=True
        )
        
        if not entries:
            return 0

        streak = 1
        last_date = datetime.strptime(entries[0]['date'], '%Y-%m-%d')
        
        for entry in entries[1:]:
            current_date = datetime.strptime(entry['date'], '%Y-%m-%d')
            if (last_date - current_date).days == 1:
                streak += 1
                last_date = current_date
            else:
                break
                
        return streak
