import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, timedelta

def create_completion_heatmap(tracking_data, habits):
    """Create a heatmap of habit completion."""
    # Prepare data
    df = pd.DataFrame(tracking_data)
    if df.empty:
        return None
        
    df['date'] = pd.to_datetime(df['date'])
    df = df.pivot_table(
        index='habit_id',
        columns='date',
        values='completed',
        aggfunc='first'
    ).fillna(False)
    
    # Create heatmap
    fig = go.Figure(data=go.Heatmap(
        z=df.values,
        x=df.columns,
        y=[habits[i]['name'] for i in df.index],
        colorscale=[[0, '#fee8c8'], [1, '#e34a33']],
        showscale=False
    ))
    
    fig.update_layout(
        title='Habit Completion Heatmap',
        xaxis_title='Date',
        yaxis_title='Habit',
        height=300,
        margin=dict(l=10, r=10, t=30, b=10)
    )
    
    return fig

def create_completion_rate_chart(tracking_data, habits):
    """Create a bar chart showing completion rates for each habit."""
    if not tracking_data:
        return None
        
    df = pd.DataFrame(tracking_data)
    completion_rates = df.groupby('habit_id')['completed'].mean().reset_index()
    completion_rates['habit_name'] = completion_rates['habit_id'].apply(
        lambda x: next(h['name'] for h in habits if h['id'] == x)
    )
    
    fig = go.Figure(data=go.Bar(
        x=completion_rates['habit_name'],
        y=completion_rates['completed'] * 100,
        marker_color='#e34a33'
    ))
    
    fig.update_layout(
        title='Habit Completion Rates',
        xaxis_title='Habit',
        yaxis_title='Completion Rate (%)',
        height=300,
        margin=dict(l=10, r=10, t=30, b=10)
    )
    
    return fig
